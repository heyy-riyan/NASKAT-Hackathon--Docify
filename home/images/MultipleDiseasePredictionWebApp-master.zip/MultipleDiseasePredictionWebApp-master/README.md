# MultipleDiseasePredictionWebApp

# About
This is a web app capable of preditcting various disease such as coronary heart disease,Breast cancer, Diabetes melitus,Parkinsons disease etc.

# INTRODUCTION/ MOTIVATION
Our project intends to provide a user-friendly platform for cross-validating disease diagnosis results immediately, as well as to raise awareness among the general public and offer safety measures. With technological advancements and mobile phones being the most used user-friendly device, an application that predicts the most common lifestyle diseases such as diabetes, heart disease, cancer, and so on will be extremely valuable.

# web app home page 
![image](https://user-images.githubusercontent.com/91358027/200597095-0466ee09-87db-40b9-b79d-4cd89b2e3b5b.png)

# Web app link
https://multiple-disease-pred-webapp.herokuapp.com/
